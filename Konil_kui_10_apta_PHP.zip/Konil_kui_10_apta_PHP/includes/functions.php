<?php
if (session_status() !== PHP_SESSION_ACTIVE) session_start();
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function go(string $path): never { header('Location: '.$path); exit; }
function logged(): bool { return isset($_SESSION['user']); }
function require_login(): void { if (!logged()) go('index.php'); }
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(16)); return $_SESSION['csrf']; }
function check_csrf(): void { if (!hash_equals(csrf(), (string)($_POST['csrf'] ?? ''))) { http_response_code(400); exit('Форма токені жарамсыз. Бетті жаңартыңыз.'); } }
function account_data(): array { if (!isset($_SESSION['data'])) $_SESSION['data']=['entries'=>[],'goals'=>[],'reminders'=>[]]; return $_SESSION['data']; }
function valid_date(string $date): bool { $d=DateTimeImmutable::createFromFormat('!Y-m-d',$date); return $d && $d->format('Y-m-d')===$date; }
function flash(string $message): void { $_SESSION['flash']=$message; }
