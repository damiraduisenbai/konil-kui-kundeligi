<?php require_once __DIR__.'/includes/functions.php'; if (logged()) go('home.php'); $error='';
if ($_SERVER['REQUEST_METHOD']==='POST') { check_csrf(); $email=trim((string)($_POST['email']??'')); $pass=(string)($_POST['password']??''); $account=$_SESSION['demo_account']??null;
if (!filter_var($email,FILTER_VALIDATE_EMAIL)||!$account||!hash_equals($account['email'],$email)||!password_verify($pass,$account['hash'])) $error='Email немесе құпиясөз дұрыс емес.';
else {session_regenerate_id(true);$_SESSION['user']=['name'=>$account['name'],'email'=>$email];go('home.php');} }
$pageTitle='Жүйеге кіру'; include __DIR__.'/includes/header.php'; ?>
<div class="card"><h2>Жүйеге кіру</h2><?php if($error): ?><p class="error"><?=e($error)?></p><?php endif; ?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><label>Email</label><input name="email" type="email" required placeholder="Email" value="<?=e($_POST['email']??'')?>"><label>Құпиясөз</label><input name="password" type="password" required placeholder="Құпиясөз"><button type="submit">Кіру</button><a class="btn" href="register.php">Тіркелу</a></form><p class="muted">10-апта: аккаунт пен жазбалар PHP сессиясында уақытша сақталады.</p></div>
<?php include __DIR__.'/includes/footer.php'; ?>
