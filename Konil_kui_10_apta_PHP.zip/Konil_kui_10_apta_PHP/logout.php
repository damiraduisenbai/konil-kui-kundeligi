<?php require_once __DIR__.'/includes/functions.php';unset($_SESSION['user']);flash('Жүйеден шықтыңыз.');go('index.php');
