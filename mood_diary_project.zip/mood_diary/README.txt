КӨҢІЛ КҮЙ КҮНДЕЛІГІ — ІСКЕ ҚОСУ

1. XAMPP орнатыңыз.
2. Apache және MySQL қызметтерін қосыңыз.
3. mood_diary папкасын XAMPP ішіндегі htdocs папкасына көшіріңіз.
4. Браузерден http://localhost/phpmyadmin ашыңыз.
5. Import арқылы database.sql файлын импорттаңыз (немесе SQL кодын орындаңыз).
6. Браузерден http://localhost/mood_diary/register.php ашыңыз.
7. Тіркеліп, жүйеге кіріңіз.

Ескерту:
Егер MySQL root пайдаланушысының паролі бос болмаса, db.php ішіндегі
$password мәнін өз пароліңізге өзгертіңіз.

Жоба файлдары:
db.php       — MySQL дерекқорына PDO арқылы қосылу
register.php — тіркелу және парольді password_hash() арқылы сақтау
login.php    — жүйеге кіру және password_verify()
index.php    — қорғалған күнделік беті, көңіл күй жазбасын сақтау
logout.php   — жүйеден шығу
style.css    — қарапайым дизайн
database.sql — дерекқор мен кестелерді құру
