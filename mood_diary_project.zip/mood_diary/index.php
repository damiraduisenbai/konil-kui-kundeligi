<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit;
}

require "db.php";
$message = "";

if (isset($_POST["save_mood"])) {
    $mood = $_POST["mood"];
    $note = trim($_POST["note"]);

    $stmt = $conn->prepare(
        "INSERT INTO moods (user_id, mood, note) VALUES (?, ?, ?)"
    );
    $stmt->execute([$_SESSION["user_id"], $mood, $note]);
    $message = "Көңіл күйіңіз сақталды!";
}

$stmt = $conn->prepare(
    "SELECT mood, note, created_at FROM moods WHERE user_id = ? ORDER BY id DESC"
);
$stmt->execute([$_SESSION["user_id"]]);
$moods = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <title>Менің күнделігім</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container wide">
    <div class="top">
        <h1>Көңіл күй күнделігі</h1>
        <a href="logout.php">Шығу</a>
    </div>

    <h2>Сәлем, <?= htmlspecialchars($_SESSION["username"]) ?>!</h2>
    <p>Бүгінгі көңіл күйің қандай?</p>
    <p class="message"><?= htmlspecialchars($message) ?></p>

    <form method="POST">
        <select name="mood" required>
            <option value="😊 Жақсы">😊 Жақсы</option>
            <option value="❤️ Керемет">❤️ Керемет</option>
            <option value="😔 Көңілсіз">😔 Көңілсіз</option>
            <option value="😴 Шаршадым">😴 Шаршадым</option>
        </select>
        <textarea name="note" placeholder="Бүгінгі күнің туралы жаз..."></textarea>
        <button type="submit" name="save_mood">Сақтау</button>
    </form>

    <h2>Менің жазбаларым</h2>
    <?php if (count($moods) == 0): ?>
        <p>Әзірге жазба жоқ.</p>
    <?php else: ?>
        <?php foreach ($moods as $item): ?>
            <div class="entry">
                <strong><?= htmlspecialchars($item["mood"]) ?></strong>
                <p><?= nl2br(htmlspecialchars($item["note"])) ?></p>
                <small><?= htmlspecialchars($item["created_at"]) ?></small>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
</body>
</html>
