<?php
session_start();
require "db.php";

$message = "";

if (isset($_POST["login"])) {
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($password, $user["password"])) {
        session_regenerate_id(true);
        $_SESSION["user_id"] = $user["id"];
        $_SESSION["username"] = $user["username"];
        header("Location: index.php");
        exit;
    } else {
        $message = "Email немесе пароль қате!";
    }
}
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <title>Кіру - Көңіл күй күнделігі</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Көңіл күй күнделігі</h1>
    <h2>Жүйеге кіру</h2>
    <p class="message"><?= htmlspecialchars($message) ?></p>
    <form method="POST">
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Пароль" required>
        <button type="submit" name="login">Кіру</button>
    </form>
    <p>Аккаунтыңыз жоқ па? <a href="register.php">Тіркелу</a></p>
</div>
</body>
</html>
