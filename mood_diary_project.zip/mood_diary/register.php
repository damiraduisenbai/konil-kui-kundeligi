<?php
session_start();
require "db.php";

$message = "";

if (isset($_POST["register"])) {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];

    if ($name === "" || $email === "" || $password === "") {
        $message = "Барлық жолды толтырыңыз!";
    } else {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->execute([$email]);

        if ($check->fetch()) {
            $message = "Бұл email бұрын тіркелген!";
        } else {
            $hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare(
                "INSERT INTO users (username, email, password) VALUES (?, ?, ?)"
            );
            $stmt->execute([$name, $email, $hash]);
            $message = "Тіркелу сәтті аяқталды! Енді жүйеге кіріңіз.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="kk">
<head>
    <meta charset="UTF-8">
    <title>Тіркелу - Көңіл күй күнделігі</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="container">
    <h1>Көңіл күй күнделігі</h1>
    <h2>Тіркелу</h2>
    <p class="message"><?= htmlspecialchars($message) ?></p>
    <form method="POST">
        <input type="text" name="name" placeholder="Атыңыз" required>
        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Пароль" required>
        <button type="submit" name="register">Тіркелу</button>
    </form>
    <p>Аккаунтыңыз бар ма? <a href="login.php">Кіру</a></p>
</div>
</body>
</html>
